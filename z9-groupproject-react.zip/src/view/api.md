感谢您在Patreon上的支持!这是您的TheMealDB和cocktaildb V2 API密钥，它包含所有升级的API调用和新的限制。
9973533
所有的说明都在API教程页面上，只需在URL中更改API密钥和V1到V2。
例如，新的API URL将是:
https://www.thecocktaildb.com/api/json/v2/9973533/recent.php
https://www.themealdb.com/api/json/v2/9973533/latest.php
你可以在这里阅读所有的API说明:
https://www.thecocktaildb.com/api.php
https://www.themealdb.com/api.php
作为支持者，你还可以在网站上添加鸡尾酒和膳食。在添加新内容之前，请确保你有一个漂亮的高质量(700x700像素)的图像。